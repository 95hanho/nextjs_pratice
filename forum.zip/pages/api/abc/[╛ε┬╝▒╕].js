export default function handler(요청, 응답) {
	console.log(요청.query);
	console.log("안녕");
}
