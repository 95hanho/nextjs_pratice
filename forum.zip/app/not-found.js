export default function NotFound() {
	return <div>없는 페이지에용</div>;
}
