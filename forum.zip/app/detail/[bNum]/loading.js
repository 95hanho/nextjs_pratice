export default function Loding() {
	return <h4>로딩중!!!!!!!!!!!</h4>;
}
