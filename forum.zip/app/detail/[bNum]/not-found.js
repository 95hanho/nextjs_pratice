export default function NotFound() {
	return <h1>404 에러다아아아아!!!!!!!!!!!!!!</h1>;
}
